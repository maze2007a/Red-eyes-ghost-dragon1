local s,id=GetID()
local SET_RED_EYES=0x3b
local RED_EYES_BLACK_DRAGON=74677422

function s.initial_effect(c)
	-- Synchro Summon: 1 "Red-Eyes" Tuner + 1+ non-Tuner monsters
	Synchro.AddProcedure(
		c,
		aux.FilterBoolFunctionEx(Card.IsSetCard,SET_RED_EYES),1,1,
		Synchro.NonTuner(nil),1,99
	)
	c:EnableReviveLimit()

	-- This card's name becomes "Red-Eyes Black Dragon" on the field and in the GY
	local e0=Effect.CreateEffect(c)
	e0:SetType(EFFECT_TYPE_SINGLE)
	e0:SetProperty(EFFECT_FLAG_SINGLE_RANGE)
	e0:SetCode(EFFECT_CHANGE_CODE)
	e0:SetRange(LOCATION_MZONE+LOCATION_GRAVE)
	e0:SetValue(RED_EYES_BLACK_DRAGON)
	c:RegisterEffect(e0)

	-- Cannot be Tributed
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_SINGLE)
	e1:SetProperty(EFFECT_FLAG_SINGLE_RANGE)
	e1:SetRange(LOCATION_MZONE)
	e1:SetCode(EFFECT_CANNOT_RELEASE)
	e1:SetValue(1)
	c:RegisterEffect(e1)

	-- Cannot be destroyed by card effects
	local e2=Effect.CreateEffect(c)
	e2:SetType(EFFECT_TYPE_SINGLE)
	e2:SetProperty(EFFECT_FLAG_SINGLE_RANGE)
	e2:SetRange(LOCATION_MZONE)
	e2:SetCode(EFFECT_INDESTRUCTABLE_EFFECT)
	e2:SetValue(1)
	c:RegisterEffect(e2)

	-- If Special Summoned: Special Summon 1 monster that mentions "Red-Eyes"
	local e3=Effect.CreateEffect(c)
	e3:SetDescription(aux.Stringid(id,0))
	e3:SetCategory(CATEGORY_SPECIAL_SUMMON)
	e3:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_TRIGGER_O)
	e3:SetProperty(EFFECT_FLAG_DELAY)
	e3:SetCode(EVENT_SPSUMMON_SUCCESS)
	e3:SetTarget(s.sptg)
	e3:SetOperation(s.spop)
	c:RegisterEffect(e3)

	-- Once per turn (Quick Effect): copy 1 Effect Monster's effects
	local e4=Effect.CreateEffect(c)
	e4:SetDescription(aux.Stringid(id,1))
	e4:SetType(EFFECT_TYPE_QUICK_O)
	e4:SetProperty(EFFECT_FLAG_CARD_TARGET)
	e4:SetCode(EVENT_FREE_CHAIN)
	e4:SetRange(LOCATION_MZONE)
	e4:SetCountLimit(1,id)
	e4:SetTarget(s.copytg)
	e4:SetOperation(s.copyop)
	c:RegisterEffect(e4)

	-- GY effect: banish this card; Special Summon 1 "Red-Eyes" monster
	local e5=Effect.CreateEffect(c)
	e5:SetDescription(aux.Stringid(id,2))
	e5:SetCategory(CATEGORY_SPECIAL_SUMMON)
	e5:SetType(EFFECT_TYPE_IGNITION)
	e5:SetRange(LOCATION_GRAVE)
	e5:SetCost(s.gycost)
	e5:SetTarget(s.gytg)
	e5:SetOperation(s.gyop)
	c:RegisterEffect(e5)
end

-- Monster that mentions "Red-Eyes"
function s.spfilter(c,e,tp)
	return c:IsMonster()
		and c:ListsArchetype(SET_RED_EYES)
		and c:IsCanBeSpecialSummoned(e,0,tp,false,false)
end

function s.sptg(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then
		return Duel.GetLocationCount(tp,LOCATION_MZONE)>0
			and Duel.IsExistingMatchingCard(
				s.spfilter,
				tp,
				LOCATION_HAND+LOCATION_DECK+LOCATION_GRAVE,
				0,
				1,
				nil,
				e,
				tp
			)
	end
	Duel.SetOperationInfo(
		0,
		CATEGORY_SPECIAL_SUMMON,
		nil,
		1,
		tp,
		LOCATION_HAND+LOCATION_DECK+LOCATION_GRAVE
	)
end

function s.spop(e,tp,eg,ep,ev,re,r,rp)
	if Duel.GetLocationCount(tp,LOCATION_MZONE)<=0 then return end

	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
	local g=Duel.SelectMatchingCard(
		tp,
		s.spfilter,
		tp,
		LOCATION_HAND+LOCATION_DECK+LOCATION_GRAVE,
		0,
		1,
		1,
		nil,
		e,
		tp
	)

	local tc=g:GetFirst()
	if tc then
		Duel.SpecialSummon(tc,0,tp,tp,false,false,POS_FACEUP)
	end
end

-- Copy target
function s.copyfilter(c)
	return c:IsMonster() and c:IsType(TYPE_EFFECT)
end

function s.copytg(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
	if chkc then
		return chkc:IsLocation(LOCATION_MZONE+LOCATION_GRAVE)
			and s.copyfilter(chkc)
	end

	if chk==0 then
		return Duel.IsExistingTarget(
			s.copyfilter,
			tp,
			LOCATION_MZONE+LOCATION_GRAVE,
			LOCATION_MZONE+LOCATION_GRAVE,
			1,
			nil
		)
	end

	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_TARGET)
	Duel.SelectTarget(
		tp,
		s.copyfilter,
		tp,
		LOCATION_MZONE+LOCATION_GRAVE,
		LOCATION_MZONE+LOCATION_GRAVE,
		1,
		1,
		nil
	)
end

function s.copyop(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local tc=Duel.GetFirstTarget()

	if not c:IsFaceup() then return end
	if not tc or not tc:IsRelateToEffect(e) then return end

	local code=tc:GetOriginalCode()

	c:CopyEffect(
		code,
		RESET_EVENT+RESETS_STANDARD+RESET_PHASE+PHASE_END,
		1
	)
end

-- Banish this card from GY as cost
function s.gycost(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then
		return e:GetHandler():IsAbleToRemoveAsCost()
	end
	Duel.Remove(e:GetHandler(),POS_FACEUP,REASON_COST)
end

-- Red-Eyes monster except this card
function s.gyfilter(c,e,tp)
	return c:IsMonster()
		and c:IsSetCard(SET_RED_EYES)
		and c:GetOriginalCode()~=id
		and c:IsCanBeSpecialSummoned(e,0,tp,true,true)
end

function s.gytg(e,tp,eg,ep,ev,re,r,rp,chk)
	local loc=
		LOCATION_HAND+
		LOCATION_DECK+
		LOCATION_GRAVE+
		LOCATION_EXTRA+
		LOCATION_REMOVED

	if chk==0 then
		return Duel.GetLocationCount(tp,LOCATION_MZONE)>0
			and Duel.IsExistingMatchingCard(
				s.gyfilter,
				tp,
				loc,
				0,
				1,
				nil,
				e,
				tp
			)
	end

	Duel.SetOperationInfo(
		0,
		CATEGORY_SPECIAL_SUMMON,
		nil,
		1,
		tp,
		loc
	)
end

function s.gyop(e,tp,eg,ep,ev,re,r,rp)
	if Duel.GetLocationCount(tp,LOCATION_MZONE)<=0 then return end

	local loc=
		LOCATION_HAND+
		LOCATION_DECK+
		LOCATION_GRAVE+
		LOCATION_EXTRA+
		LOCATION_REMOVED

	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
	local g=Duel.SelectMatchingCard(
		tp,
		s.gyfilter,
		tp,
		loc,
		0,
		1,
		1,
		nil,
		e,
		tp
	)

	local tc=g:GetFirst()
	if tc then
		Duel.SpecialSummon(tc,0,tp,tp,true,true,POS_FACEUP)
	end
end